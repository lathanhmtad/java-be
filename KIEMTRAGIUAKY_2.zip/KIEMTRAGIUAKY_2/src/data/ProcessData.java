package data;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import entities.LoaiTin;
import entities.TinTuc;

public class ProcessData {
	public static ArrayList<LoaiTin> getListLoaiTin() {
		ArrayList<LoaiTin> result = new ArrayList<>();

		Connection conn = SQLServerConnection.getConnection();

		PreparedStatement ps = null;

		ResultSet rs = null;
		try {
			String query = "select * from tbLOAI";

			ps = conn.prepareStatement(query);

			rs = ps.executeQuery();

			while (rs.next()) {
				int id = rs.getInt(1);
				String tenLoai = rs.getString(2);

				LoaiTin loaiTin = new LoaiTin(id, tenLoai);

				result.add(loaiTin);

			}

			ps.close();
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

		}

		return result;

	}

	public static ArrayList<TinTuc> getListTinTuc() {
		ArrayList<TinTuc> result = new ArrayList<>();

		Connection conn = SQLServerConnection.getConnection();

		PreparedStatement ps = null;

		ResultSet rs = null;
		try {
			String query = "select * from tbTINTUC";

			ps = conn.prepareStatement(query);

			rs = ps.executeQuery();

			while (rs.next()) {
				int id = rs.getInt(1);
				String tieuDe = rs.getString(2);
				String noiDung = rs.getString(3);

				TinTuc tinTuc = new TinTuc();
				tinTuc.setMaTinTuc(id);
				tinTuc.setTieuDe(tieuDe);
				tinTuc.setNoiDung(noiDung);

				result.add(tinTuc);

			}

			ps.close();
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

		}

		return result;
	}

	public int insertTinTuc() {
		Connection conn = SQLServerConnection.getConnection();
		PreparedStatement ps = null;
		int result = 0;
		try {
			String query = "insert into tbTINTUC values(?, ?, ?)";

			ps = conn.prepareStatement(query);

			result = ps.executeUpdate();

			ps.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

		}

		return result;
	}
}
