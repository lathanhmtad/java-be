package test;

import java.sql.Connection;
import java.util.ArrayList;

import data.ProcessData;
import data.SQLServerConnection;
import entities.LoaiTin;
import entities.TinTuc;
import presentation.PostView;

public class Main {
	public static void main(String[] args) {
		new PostView();
	}
}
