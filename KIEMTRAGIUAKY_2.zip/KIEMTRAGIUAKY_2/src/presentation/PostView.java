package presentation;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import business.BusinessLogicPost;
import data.ProcessData;
import entities.LoaiTin;
import entities.TinTuc;

import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;

public class PostView extends JFrame implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public JPanel contentPane;
	public JTextField textFieldMaTinTuc;
	public JLabel lblTinTc;
	public JTextField textFieldTieuDe;
	public JTable table;
	public JComboBox<String> comboBoxLoaiTin;
	
	private BusinessLogicPost businessLogicPost;
	public JButton btnAdd;
	public JButton btnDelete;
	public JTextArea textAreaContent;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PostView frame = new PostView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PostView() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 561);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
		businessLogicPost = new BusinessLogicPost(this);
		
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textFieldMaTinTuc = new JTextField();
		textFieldMaTinTuc.setBounds(154, 10, 250, 32);
		contentPane.add(textFieldMaTinTuc);
		textFieldMaTinTuc.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Mã tin tức");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel.setBounds(52, 23, 79, 17);
		contentPane.add(lblNewLabel);
		
		lblTinTc = new JLabel("Tiêu đề");
		lblTinTc.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblTinTc.setBounds(52, 75, 79, 17);
		contentPane.add(lblTinTc);
		
		textFieldTieuDe = new JTextField();
		textFieldTieuDe.setColumns(10);
		textFieldTieuDe.setBounds(154, 62, 250, 32);
		contentPane.add(textFieldTieuDe);
		
		textAreaContent = new JTextArea();
		textAreaContent.setBounds(10, 194, 712, 93);
		contentPane.add(textAreaContent);
		
		JLabel lblNewLabel_2 = new JLabel("Nội dung");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(10, 157, 58, 17);
		contentPane.add(lblNewLabel_2);
		
		ArrayList<LoaiTin> danhSachLoaiTin = ProcessData.getListLoaiTin();
		ArrayList<String> danhSachTenLoaiTin = new ArrayList<>();
		for (LoaiTin loaiTin : danhSachLoaiTin) {
			danhSachTenLoaiTin.add(loaiTin.getTenLoai());
		}
		
		DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(danhSachTenLoaiTin.toArray(new String[0]));
		comboBoxLoaiTin = new JComboBox<>(model);
		comboBoxLoaiTin.setBounds(154, 116, 250, 21);
		contentPane.add(comboBoxLoaiTin);
		
		JLabel lblNewLabel_1 = new JLabel("Loại tin");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(52, 120, 46, 17);
		contentPane.add(lblNewLabel_1);
		
		
		String data[][] = {};
		String header[] = { "Mã tin tức", "Tiêu đề"};
		DefaultTableModel tableModel = new DefaultTableModel(data, header);
		
		// insert data to table
		ArrayList<TinTuc> danhSachTinTuc = ProcessData.getListTinTuc();
		for (TinTuc tinTuc : danhSachTinTuc) {
			Object[] newRow = {tinTuc.getMaTinTuc(), tinTuc.getNoiDung()};
			tableModel.addRow(newRow);
		}
		table = new JTable(tableModel);
		
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(10, 357, 887, 157);
		contentPane.add(scrollPane);
		
		
		
		btnAdd = new JButton("Thêm mới");
		btnAdd.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnAdd.setBounds(20, 296, 111, 23);
		contentPane.add(btnAdd);
		btnAdd.addActionListener(this);
		
		
		btnDelete = new JButton("Xóa");
		btnDelete.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnDelete.setBounds(147, 297, 85, 21);
		contentPane.add(btnDelete);
		btnDelete.addActionListener(this);
		
		JButton btnEdit = new JButton("Sửa");
		btnEdit.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnEdit.setBounds(242, 297, 85, 21);
		contentPane.add(btnEdit);
		
		JButton btnSearch = new JButton("Tìm");
		btnSearch.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnSearch.setBounds(358, 297, 85, 21);
		contentPane.add(btnSearch);
		
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == btnAdd) {
			businessLogicPost.insert();
		}
	}
}
