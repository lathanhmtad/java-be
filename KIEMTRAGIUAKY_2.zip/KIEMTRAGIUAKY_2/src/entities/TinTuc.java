package entities;

public class TinTuc {
	private int maTinTuc;
	private String tieuDe;
	private String noiDung;
	private LoaiTin loaiTin;

	public TinTuc() {
	}

	public int getMaTinTuc() {
		return maTinTuc;
	}

	public void setMaTinTuc(int maTinTuc) {
		this.maTinTuc = maTinTuc;
	}

	public String getTieuDe() {
		return tieuDe;
	}

	public void setTieuDe(String tieuDe) {
		this.tieuDe = tieuDe;
	}

	public String getNoiDung() {
		return noiDung;
	}

	public void setNoiDung(String noiDung) {
		this.noiDung = noiDung;
	}

	public LoaiTin getLoaiTin() {
		return loaiTin;
	}

	public void setLoaiTin(LoaiTin loaiTin) {
		this.loaiTin = loaiTin;
	}

	@Override
	public String toString() {
		return "TinTuc [maTinTuc=" + maTinTuc + ", tieuDe=" + tieuDe + ", noiDung=" + noiDung + ", loaiTin=" + loaiTin
				+ "]";
	}

}
