package business;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import entities.TinTuc;
import presentation.PostView;


public class BusinessLogicPost {
	PostView postView;
	
	public BusinessLogicPost(PostView postView) {
		this.postView = postView;
	}


	public void insert() {
		String tieuDe = postView.textFieldTieuDe.getText();
		String loaiTin = (String) postView.comboBoxLoaiTin.getSelectedItem();
		String noiDung = postView.textAreaContent.getText();
		
		TinTuc tinTuc = new TinTuc();
		tinTuc.setTieuDe(tieuDe);
		tinTuc.setNoiDung(noiDung);
	}
	
	
	
}
